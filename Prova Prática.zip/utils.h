#define utils_h

float validaNaturais(float i){
    if (i < 0){
        return 1;
    }else{
        return 0;
    }
}
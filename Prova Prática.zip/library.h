#define library_h 

#include <stdio.h>
#include <stdlib.h>
#include <time.h> //https://forum.scriptbrasil.com.br/topic/101778-contador-de-tempo-em-milisegundos/
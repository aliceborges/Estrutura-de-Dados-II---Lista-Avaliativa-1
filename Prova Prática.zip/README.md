# Estrutura de Dados II
### Prova Prática I
### Aluna: Alice Borges
#### Feito utlizando o Visual Studio Code e S.O. Ubuntu 18.10

Para executar o projeto:
- [X] Ter instalado o GCC

Execute no seu terminal: 
```
gcc lista_avaliativa_1.c -o lista
./lista
```
#include "library.h"
#include "utils.h"
#include "list_questions.h"

// 1ª LISTA PRÁTICA
// Aluno(s): Alice Borges

int main(){
    q1();
    q2();
    q3();
    q4_q5();
    q6();
    q7();
    q8();
    q9();
    q10_11();
    q13();
    q14();
    q16();
    q17();
    q18();
    q20();
}
